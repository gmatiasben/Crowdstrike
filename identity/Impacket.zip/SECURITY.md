Security Policy
===============

Although this initiative is not meant to be used in productive environments,
if you consider that you have identified an issue that might affect the
security of its users, or you understand that the tool is being abused,
you can contact us at oss-security@secureauth.com.
